# extention-chrome-extract-seo-tools

Copie le title, meta description et le texte alternatif d'une image

